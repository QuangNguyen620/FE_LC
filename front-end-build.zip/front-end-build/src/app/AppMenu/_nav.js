import React from 'react';
import { HomeOutlined, AppstoreOutlined } from '@ant-design/icons';

export default {
  items: [
    {
      name: 'Trang chủ',
      url: '/',
      icon: <HomeOutlined />,
    },
  ],
};
