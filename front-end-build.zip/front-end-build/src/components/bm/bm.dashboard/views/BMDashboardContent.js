import React from 'react';
// import { useTranslation } from 'react-i18next';
import {} from '@ant-design/icons';

const BMDashboardContent = ({ lang = 'vi', ...props }) => {
  return <></>;
};

export default BMDashboardContent;
