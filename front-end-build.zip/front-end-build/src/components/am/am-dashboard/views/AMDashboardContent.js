import React, { useState } from 'react';
// import { useTranslation } from 'react-i18next';
import {} from '@ant-design/icons';
import { Form, Input, Button, Select } from 'antd';
// import { KTBodyText, KTButton, KTHeading, KTSubTitle, KTLogo } from 'core/ui';
// import ic_fis from 'assets/img/brand/logo_fis.png';
// import css from './AMDashboard.less';

const { Option } = Select;
// const layout = {
//   labelCol: {
//     span: 8,
//   },
//   wrapperCol: {
//     span: 16,
//   },
// };
// const tailLayout = {
//   wrapperCol: {
//     offset: 8,
//     span: 16,
//   },
// };

const AMDashboardContent = ({ lang = 'vi', ...props }) => {
  const [form] = Form.useForm();


  return <></>;
};

export default AMDashboardContent;
